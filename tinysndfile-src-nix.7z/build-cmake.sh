#!/bin/sh
clear
reset

# clean previous files
rm CMakeCache.txt


ANDROID_NDK_PATH=/home/bindesh/bin/ndk
ANDROID_SDK_PATH=/home/bindesh/bin/android-sdk
ANDROID_NDK=${ANDROID_NDK_PATH}

ANDROID_CMAKE_PATH=${ANDROID_SDK_PATH}/cmake/3.6.3155560/bin
ANDROID_CMAKE_TOOLCHAIN=${ANDROID_NDK_PATH}/build/cmake/android.toolchain.cmake
#ANDROID_CMAKE_TOOLCHAIN=/media/bindesh/WORK/SDK_IDE/android-sdk-linux-windows/cmake/3.6.3155560/android.toolchain.cmake

ANDROID_API=9
ANDROID_ARCH=arm
ANDROID_ABI=armeabi-v7a
ANDROID_PLATFORM=android-${ANDROID_API}
ANDROID_ARCH=arch-${ANDROID_ARCH}
#ANDROID_LIB_NAME=png-${ANDROID_ABI}

#set(ANDROID_PNG_LIB_NAME png-${ANDROID_ABI} )


#-DCMAKE_LIBRARY_OUTPUT_DIRECTORY=./${ANDROID_ABI}
#ZLIB_ROOT="${ANDROID_NDK_PATH}/platforms/${ANDROID_PLATFORM}/${ANDROID_ARCH}/usr/"



# -DCMAKE_MAKE_PROGRAM=${ANDROID_CMAKE_PATH}/ninja
# -G"Android Gradle - Ninja"
#-DCMAKE_TOOLCHAIN_FILE=${ANDROID_CMAKE_TOOLCHAIN}

${ANDROID_CMAKE_PATH}/cmake -DCMAKE_TOOLCHAIN_FILE=${ANDROID_CMAKE_TOOLCHAIN} -DANDROID_ABI=${ANDROID_ABI} -DANDROID_TOOLCHAIN=gcc -DANDROID_NATIVE_API_LEVEL=${ANDROID_API} -DANDROID_PLATFORM=${ANDROID_PLATFORM} -DCMAKE_MAKE_PROGRAM=${ANDROID_CMAKE_PATH}/ninja -G"Android Gradle - Ninja" -DCMAKE_BUILD_TYPE=Release


#${ANDROID_CMAKE_PATH}/cmake -DCMAKE_TOOLCHAIN_FILE=${ANDROID_CMAKE_TOOLCHAIN} -DCMAKE_MAKE_PROGRAM=${ANDROID_CMAKE_PATH}/ninja -G"Android Gradle - Ninja" -DANDROID_NDK=${ANDROID_NDK}
${ANDROID_CMAKE_PATH}/ninja
#make


#Executable : /home/bindesh/work/SDK_IDE/android-sdk-linux-windows/cmake/3.6.3155560/bin/cmake
#arguments : 
#-H/media/bindesh/WORK/work/programming/Android/TestApps/libpng/app
#-B/media/bindesh/WORK/work/programming/Android/TestApps/libpng/app/.externalNativeBuild/cmake/release/armeabi-v7a
#-GAndroid Gradle - Ninja
#-DANDROID_ABI=armeabi-v7a
#-DANDROID_NDK=/home/bindesh/bin/ndk
#-DCMAKE_LIBRARY_OUTPUT_DIRECTORY=/media/bindesh/WORK/work/programming/Android/TestApps/libpng/app/build/intermediates/cmake/release/obj/armeabi-v7a
#-DCMAKE_BUILD_TYPE=Release
#-DCMAKE_MAKE_PROGRAM=/home/bindesh/work/SDK_IDE/android-sdk-linux-windows/cmake/3.6.3155560/bin/ninja
#-DCMAKE_TOOLCHAIN_FILE=/home/bindesh/bin/ndk/build/cmake/android.toolchain.cmake
#-DANDROID_NATIVE_API_LEVEL=9
#-DCMAKE_CXX_FLAGS=
#jvmArgs : 
