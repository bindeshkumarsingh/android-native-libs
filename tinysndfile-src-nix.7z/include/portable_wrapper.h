

#ifndef _PORTABLE_WRAPPER
	#define 
	
	
#include <stdio.h>


#define LOG_ALWAYS_FATAL printf
	
#endif