Project: 		tinysndfile
Platform: 		*NIX (original is Android only)
Purpose:		Read wav files to get PCM data. Alternative to libsndfile.
Download link: https://android.googlesource.com/platform/system/media/+/master/audio_utils


Due to GPL license of libsndfile a need for alternative is always there. I downloaded audio_utils 
then deleted & edited some files to remove Android only parts.



Why tinysndfile?


Look at libsndfile page http://www.mega-nerd.com/libsndfile/ . Below text is read from the same -


"Licensing

libsndfile is released under the terms of the GNU Lesser General Public License, of which there are two versions; version 2.1 and version 3. To maximise the compatibility of libsndfile, the user may choose to use libsndfile under either of the above two licenses. You can also read a simple explanation of the ideas behind the GPL and the LGPL here.

You can use libsndfile with Free Software, Open Source, proprietary, shareware or other closed source applications as long as libsndfile is used as a dynamically loaded library and you abide by a small number of other conditions (read the LGPL for more info). With applications released under the GNU GPL you can also use libsndfile statically linked to your application.

I would like to see libsndfile used as widely as possible but I would prefer it if you released software that uses libsndfile as Free Software or Open Source. However, if you put in a great deal of effort building a significant application which simply uses libsndfile for file I/O, then I have no problem with you releasing that as closed source and charging as much money as you want for it as long as you abide by the license."


